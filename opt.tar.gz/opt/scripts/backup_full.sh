#!/bin/bash

#backup_full.sh - Script para hacer backups

#Función para ayudar
show_help() {
	echo "Uso: $0 ORIGEN DESTINO"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Este script genera un archivo .tar.gz con nombre basado en la fecha"
	exit 0
}

#Validar argumentos
if [[ "$1" == "-help" || "$1" == "--help" ]]; then
	show_help
fi

if [[ $# -ne 2 ]]; then
	echo "Error: se requieren 2 argumentos (origen y destino). Usa -help para ayuda"
	exit 1
fi

ORIGEN=$1
DESTINO=$2

#Validar que ambos directorios existan
if [[ ! -d "$ORIGEN" ]]; then
	echo "Error: el directorio de origen '$ORIGEN' no existe."
	exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
	echo "Error: el directorio de destino '$DESTINO' no existe"
	exit 1
fi

#Validar que estén montados (buscando en /proc/mounts)
if ! mountpoint -q "$DESTINO"; then
	echo "Error: el directorio de destino '$DESTINO' no está montado."
	exit 1
fi

#Formato de nombre: nombre_bkp_YYYYMMDD.tar.gz
DATE=$(date +%Y%m%d)
DIR_NAME=$(basename "$ORIGEN")
BACKUP_FILE="${DESTINO}/${DIR_NAME}_bkp_${DATE}.tar.gz"

#Realizar backup
echo "Realizando backup de '$ORIGEN' en '$BACKUP_FILE'..."
tar -czf "$BACKUP_FILE" -C "$ORIGEN" .
echo "Backup completado exitosamente"

exit 0
